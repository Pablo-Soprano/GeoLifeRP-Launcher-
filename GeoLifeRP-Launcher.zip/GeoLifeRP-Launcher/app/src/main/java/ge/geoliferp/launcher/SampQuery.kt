package ge.geoliferp.launcher

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ServerInfo(val name: String, val players: Int, val maxPlayers: Int, val pingMs: Long)
data class PlayerInfo(val id: Int, val name: String, val score: Int, val ping: Int)

/** Real SA-MP UDP query: 'i' = server info (online status, player count), 'd' = detailed player list. */
object SampQuery {
    private fun request(ip: String, port: Int, opcode: Char, onReply: (ByteBuffer, Long) -> Unit): Boolean = try {
        val addr = InetAddress.getByName(ip)
        val req = ByteBuffer.allocate(11)
        req.put("SAMP".toByteArray())
        ip.split(".").forEach { req.put(it.toInt().toByte()) }
        req.put((port and 0xFF).toByte()).put((port shr 8 and 0xFF).toByte())
        req.put(opcode.code.toByte())
        DatagramSocket().use { s ->
            s.soTimeout = 3000
            val t0 = System.currentTimeMillis()
            s.send(DatagramPacket(req.array(), 11, addr, port))
            val buf = ByteArray(8192)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            val ping = System.currentTimeMillis() - t0
            onReply(ByteBuffer.wrap(buf, 11, p.length - 11).order(ByteOrder.LITTLE_ENDIAN), ping)
        }
        true
    } catch (e: Exception) { false }

    fun info(ip: String, port: Int): ServerInfo? {
        var r: ServerInfo? = null
        request(ip, port, 'i') { b, ping ->
            b.get() // password flag
            val pl = b.short.toInt() and 0xFFFF
            val mx = b.short.toInt() and 0xFFFF
            val len = b.int
            val nb = ByteArray(len); b.get(nb)
            r = ServerInfo(String(nb, Charsets.UTF_8), pl, mx, ping)
        }
        return r
    }

    /** Works only while the server has up to 100 players (SA-MP limitation). */
    fun players(ip: String, port: Int): List<PlayerInfo>? {
        var r: List<PlayerInfo>? = null
        request(ip, port, 'd') { b, _ ->
            val n = b.short.toInt() and 0xFFFF
            val list = ArrayList<PlayerInfo>()
            repeat(n) {
                val id = b.get().toInt() and 0xFF
                val len = b.get().toInt() and 0xFF
                val nb = ByteArray(len); b.get(nb)
                val score = b.int
                val ping = b.int
                list.add(PlayerInfo(id, String(nb, Charsets.UTF_8), score, ping))
            }
            r = list
        }
        return r
    }
}
