package ge.geoliferp.launcher

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.os.Environment
import android.provider.MediaStore
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

/** City background (red glow + skyline), drawn in code. */
class SynthBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(7)
    private val towers = List(24) { floatArrayOf(rnd.nextFloat() * 0.97f, 0.12f + rnd.nextFloat() * 0.28f, 0.03f + rnd.nextFloat() * 0.04f) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#0A0A0A"), Color.parseColor("#16070A"), Color.parseColor("#3A0A12")),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(w * 0.78f, h * 0.62f, h * 0.95f,
            Color.argb(150, 229, 9, 20), Color.argb(0, 229, 9, 20), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        for ((i, t) in towers.withIndex()) {
            val x = w * t[0]; val tw = w * t[2]; val th = h * t[1]
            p.color = Color.parseColor("#12090B"); c.drawRect(x, h - th, x + tw, h, p)
            p.color = Color.parseColor("#FF5A4D")
            var j = 0; var y = h - th + 10f
            while (y < h - 12f) {
                if ((i + j) % 3 == 0) c.drawRect(x + tw * 0.2f, y, x + tw * 0.35f, y + 6f, p)
                if ((i + j) % 4 == 1) c.drawRect(x + tw * 0.6f, y, x + tw * 0.75f, y + 6f, p)
                y += 16f; j++
            }
        }
    }
}

class MainActivity : Activity() {
    private val PINK = Color.parseColor("#E50914")
    private val ORANGE = Color.parseColor("#FF3D2E")
    private val MUTED = Color.parseColor("#9A9AA0")
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private var tab = 0
    private lateinit var views: List<View>
    private lateinit var tabTvs: List<TextView>
    private lateinit var pillTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var pingTv: TextView
    private lateinit var fill: ProgressBar
    private lateinit var chipsBox: LinearLayout
    private lateinit var infoTv: TextView
    private lateinit var socialRow: LinearLayout
    private lateinit var nick: EditText
    private lateinit var playersBox: LinearLayout
    private lateinit var installBar: ProgressBar
    private lateinit var installMsg: TextView
    private lateinit var installBtn: Button
    private lateinit var openZipBtn: Button
    private lateinit var heroView: ImageView
    private lateinit var dimView: View
    private var heroId = 0
    private var savedZip: Uri? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun gradBtn(text: String, filled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PINK, ORANGE)).apply {
            cornerRadius = dp(14).toFloat()
            if (!filled) { colors = intArrayOf(Color.parseColor("#33FFFFFF"), Color.parseColor("#33FFFFFF")) }
        }
        setOnClickListener { onClick() }
    }

    private fun social(res: Int, url: String) = ImageView(this).apply {
        setImageResource(res); scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginStart = dp(8) }
        setOnClickListener {
            if (url.isBlank()) Toast.makeText(this@MainActivity, "Linki jer ar aris dayenebuli", Toast.LENGTH_SHORT).show() else open(url)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.launcher_bg); scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        dimView = View(this)
        root.addView(dimView, FrameLayout.LayoutParams(-1, -1))
        heroId = resources.getIdentifier("hero", "drawable", packageName)
        heroView = ImageView(this).apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_END
            if (heroId != 0) setImageResource(heroId)
        }
        val screenH = minOf(resources.displayMetrics.heightPixels, resources.displayMetrics.widthPixels)
        root.addView(heroView, FrameLayout.LayoutParams(-2, (screenH * 0.9f).toInt(), Gravity.END or Gravity.BOTTOM).apply { setMargins(0, 0, dp(8), 0) })
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12)) }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        // ---- top bar ----
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        brand.addView(tv("GEOLIFERP", 14f, Color.WHITE, true))
        brand.addView(tv("MOBILE", 10f, ORANGE, true))
        top.addView(brand)
        val names = listOf("HOME", "PLAYERS")
        tabTvs = names.mapIndexed { i, n ->
            tv(n, 12f, MUTED, true).apply {
                letterSpacing = 0.15f; setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { haptic(); setTab(i) }
            }
        }
        top.addView(View(this), LinearLayout.LayoutParams(dp(20), 1))
        tabTvs.forEach { top.addView(it) }
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        pillTv = tv("\u25CF ...", 13f, Color.GRAY, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply { setColor(Color.parseColor("#CC141414")); cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.parseColor("#33FFFFFF")) }
        }
        top.addView(pillTv, LinearLayout.LayoutParams(-2, dp(36)))
        nick = EditText(this).apply {
            hint = "Name_Surname"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(); textSize = 13f
            setText(prefs.getString("nick", "")); setPadding(dp(16), 0, dp(16), 0); gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(Color.parseColor("#CC141414")); cornerRadius = dp(20).toFloat(); setStroke(dp(1), PINK) }
        }
        top.addView(nick, LinearLayout.LayoutParams(dp(170), dp(36)).apply { marginStart = dp(8) })
        top.addView(TextView(this).apply {
            text = "\u2699"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC141414")); setStroke(dp(1), Color.parseColor("#33FFFFFF")) }
            setOnClickListener { haptic(); setTab(2) }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(8) })
        main.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- HOME ----
        val home = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val hc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(2)) }
        val hdr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hdr.addView(View(this).apply { setBackgroundColor(PINK) }, LinearLayout.LayoutParams(dp(4), dp(20)))
        hdr.addView(tv("სერვერის სტატუსი", 16f, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0) })
        hc.addView(hdr)
        val scard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#E61A1A1A"), Color.parseColor("#E6240609")))
                .apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), Color.parseColor("#44E50914")) }
        }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusTv = tv("\u25CF ...", 12f, Color.GRAY, true).apply { letterSpacing = 0.1f }
        r1.addView(statusTv, LinearLayout.LayoutParams(0, -2, 1f))
        pingTv = tv("- ms", 12f, Color.WHITE, true)
        r1.addView(pingTv)
        scard.addView(r1)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        countTv = tv("0 / 0", 30f, Color.WHITE, true)
        r2.addView(countTv)
        r2.addView(tv("PLAYERS", 10f, Color.parseColor("#A0A0A8"), true).apply { letterSpacing = 0.15f; setPadding(dp(8), 0, 0, dp(6)) })
        scard.addView(r2)
        fill = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(PINK)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
        }
        scard.addView(fill, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(4) })
        chipsBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scard.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipsBox) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        hc.addView(scard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        hc.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val playBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PINK, ORANGE)).apply { cornerRadius = dp(10).toFloat() }
            addView(TextView(context).apply {
                text = "\u25B6"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply { setColor(Color.parseColor("#55000000")); cornerRadius = dp(10).toFloat() }
            }, LinearLayout.LayoutParams(dp(38), dp(38)))
            val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            col.addView(tv("თამაში", 20f, Color.WHITE, true))
            col.addView(tv("სერვერთან დაკავშირება", 11f, Color.parseColor("#FFE0E0")))
            addView(col)
            setOnClickListener { play() }
        }
        btnRow.addView(playBtn, LinearLayout.LayoutParams(0, dp(58), 1.35f))
        val shopBtn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply { setColor(Color.parseColor("#E6141414")); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#66E50914")) }
            addView(tv("მაღაზია", 15f, Color.WHITE, true))
            addView(tv("დონატი", 11f, PINK, true))
            setOnClickListener { open(Config.WEBSITE) }
        }
        btnRow.addView(shopBtn, LinearLayout.LayoutParams(0, dp(58), 0.65f).apply { marginStart = dp(10) })
        hc.addView(btnRow, LinearLayout.LayoutParams(-1, -2))
        infoTv = tv("${Config.SERVER_NAME} Mobile  \u00B7  v1.0", 11f, Color.parseColor("#8A8A8A"))
        hc.addView(infoTv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        home.addView(hc, LinearLayout.LayoutParams(0, -1, 1f))
        home.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        socialRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        socialRow.addView(social(R.drawable.ic_web, Config.WEBSITE))
        socialRow.addView(social(R.drawable.ic_facebook, Config.FACEBOOK))
        socialRow.addView(social(R.drawable.ic_youtube, Config.YOUTUBE))
        socialRow.addView(social(R.drawable.ic_discord, Config.DISCORD))
        socialRow.addView(social(R.drawable.ic_telegram, Config.TELEGRAM))
        socialRow.addView(social(R.drawable.ic_tiktok, Config.TIKTOK))
        root.addView(socialRow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(14)) })

        // ---- PLAYERS ----
        val playersScroll = ScrollView(this)
        playersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(8)) }
        playersScroll.addView(playersBox)

        // ---- SETTINGS ----
        val settings = ScrollView(this)
        val sc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(8)) }
        sc.addView(tv("SETTINGS", 20f, Color.WHITE, true))
        installBtn = gradBtn("CHAMOTVIRTVA / GANAXLEBA") { startInstall() }
        sc.addView(installBtn, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        installBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE; progressTintList = ColorStateList.valueOf(PINK)
        }
        sc.addView(installBar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(10) })
        installMsg = tv("", 12f, Color.LTGRAY)
        sc.addView(installMsg)
        openZipBtn = gradBtn("ZIP-IS GAXSNA (ZArchiver)", false) {
            savedZip?.let { u ->
                try {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/zip")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Gaxsna"))
                } catch (e: Exception) { Toast.makeText(this, "Gaxseni Files/ZArchiver-it: Download/GeoLifeRP_files.zip", Toast.LENGTH_LONG).show() }
            }
        }.apply { visibility = View.GONE }
        sc.addView(openZipBtn, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
        sc.addView(gradBtn("NICKNAME-IS WASHLA", false) {
            prefs.edit().remove("nick").apply(); nick.setText("")
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
        sc.addView(gradBtn("CHAMOTVIRTULI FAILEBIS WASHLA", false) {
            File(getExternalFilesDir(null), "client").deleteRecursively()
            Toast.makeText(this, "Failebi washlilia", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
        fun act(text: String, onClick: () -> Unit) =
            sc.addView(gradBtn(text, false, onClick), LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })

        sc.addView(section("GRAFIKA"))
        sc.addView(choice("Grafikis xarisxi", "gfx_quality", listOf("LOW", "MEDIUM", "HIGH"), 1))
        sc.addView(choice("Teqsturebis xarisxi", "gfx_textures", listOf("LOW", "MEDIUM", "HIGH"), 1))
        sc.addView(choice("FPS limiti", "gfx_fps", listOf("30", "60", "90"), 1))
        sc.addView(choice("Xilvadobis distancia", "gfx_draw", listOf("NEAR", "NORMAL", "FAR"), 1))
        sc.addView(choice("Anti-aliasing", "gfx_aa", listOf("OFF", "2X", "4X"), 0))
        sc.addView(toggle("Shadows (ჩრდილები)", "gfx_shadows", true))
        sc.addView(toggle("Efektebi (particles)", "gfx_effects", true))
        sc.addView(toggle("V-Sync", "gfx_vsync", true))
        sc.addView(toggle("FPS counter", "gfx_showfps", false))

        sc.addView(section("AUDIO"))
        sc.addView(choice("Zogadi xmis done", "aud_master", listOf("0%", "25%", "50%", "75%", "100%"), 3))
        sc.addView(choice("Musika", "aud_music", listOf("OFF", "LOW", "MID", "HIGH"), 2))
        sc.addView(choice("Efektebis xma", "aud_sfx", listOf("LOW", "MID", "HIGH"), 2))
        sc.addView(toggle("Radio", "aud_radio", true))

        sc.addView(section("HUD DA CHAT"))
        sc.addView(choice("HUD zoma", "hud_scale", listOf("S", "M", "L"), 1))
        sc.addView(choice("Chat-is xazebi", "chat_lines", listOf("5", "8", "12", "16"), 1))
        sc.addView(choice("Chat-is shrifti", "chat_font", listOf("S", "M", "L"), 1))
        sc.addView(toggle("HUD gamochena", "hud_show", true))
        sc.addView(toggle("Radari", "hud_radar", true))
        sc.addView(toggle("Chat-shi dro (timestamp)", "chat_time", false))

        sc.addView(section("GEIMPLEI DA MARTVA"))
        sc.addView(choice("Kameris sensitivoba", "game_sens", listOf("LOW", "MID", "HIGH"), 1))
        sc.addView(choice("Joystick-is zoma", "game_stick", listOf("S", "M", "L"), 1))
        sc.addView(toggle("Vibracia tamashshi", "game_vibration", true))
        sc.addView(toggle("Avtomaturi reconnect", "game_reconnect", true))

        sc.addView(section("LAUNCHER"))
        sc.addView(choice("Statusis ganaxleba", "refresh", listOf("3 wm", "5 wm", "10 wm"), 1))
        sc.addView(choice("Fonis shemqrobi (dim)", "ui_dim", listOf("OFF", "LIGHT", "DARK"), 1) { applyDim() })
        sc.addView(toggle("Loading ekrani gaxsnisas", "loading", true))
        sc.addView(toggle("Hero surati (personajebi)", "ui_hero", true) { setTab(tab) })
        sc.addView(toggle("Motamasheebis saxelebi mtavar ekranze", "ui_names", true) { refreshNow() })
        sc.addView(toggle("Ekrani ar tsitsxldeba (screen on)", "ui_awake", false) { applyAwake() })
        sc.addView(toggle("Vibracia ghilakebze", "ui_haptic", true))

        sc.addView(section("SERVISI"))
        act("CACHE-IS GASUFTAVEBA") {
            val files = cacheDir.listFiles() ?: emptyArray()
            val size = files.sumOf { it.length() }
            files.forEach { it.deleteRecursively() }
            Toast.makeText(this, "Gasuftavda ${size / 1024} KB", Toast.LENGTH_SHORT).show()
        }
        act("SERVERIS IP-IS KOPIREBA") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                .setPrimaryClip(android.content.ClipData.newPlainText("server", "${Config.SERVER_IP}:${Config.SERVER_PORT}"))
            Toast.makeText(this, "${Config.SERVER_IP}:${Config.SERVER_PORT} nakopirebulia", Toast.LENGTH_SHORT).show()
        }
        act("SETTINGS FAILSHI GADAGZAVNA (INI)") {
            Toast.makeText(this,
                if (exportSettings()) "Gadagzavnilia: SAMP/geoliferp_settings.ini" else "Android-ma pirdapir chaweris ufleba ar mogvca",
                Toast.LENGTH_LONG).show()
        }
        act("YVELA SETTINGS-IS AGHDGENA") {
            val n = prefs.getString("nick", "") ?: ""
            prefs.edit().clear().putString("nick", n).apply()
            recreate()
        }

        sc.addView(section("INFORMACIA"))
        val clientOk = packageManager.getLaunchIntentForPackage(Config.CLIENT_PACKAGE) != null
        val dirOk = clientDir().let { it.exists() && it.canWrite() }
        listOf(
            "Launcheris versia: 1.0",
            "Serveri: ${Config.SERVER_IP}:${Config.SERVER_PORT}",
            "SAMP klienti (${Config.CLIENT_PACKAGE}): ${if (clientOk) "dadgmulia" else "ar aris dadgmuli"}",
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Pirdapir chaweris ufleba klientis foldershi: ${if (dirOk) "ki" else "ara (zip-s ZArchiver-it xelit gaxsnit)"}"
        ).forEach { sc.addView(tv(it, 12f, Color.parseColor("#C8C8CE")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }) }
        act("DISCORD (DAXMAREBA)") { open(Config.DISCORD) }
        act("TELEGRAM") {
            if (Config.TELEGRAM.isBlank()) Toast.makeText(this, "Linki jer ar aris dayenebuli", Toast.LENGTH_SHORT).show()
            else open(Config.TELEGRAM)
        }
        sc.addView(tv("Tamashis parametrebi (GRAFIKA, AUDIO, HUD, GEIMPLEI) inaxeba launchershi da iwereba SAMP/geoliferp_settings.ini-shi mxolod roca Android-i chaweras aghmogvcems. " +
            "Tamashi mas gamoiyenebs mxolod im shemtkhvevashi, tu klienti am failis kitxulobs. LAUNCHER nawilis parametrebi pirdapir mushaobs.",
            11f, Color.parseColor("#BBBBEE")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        settings.addView(sc)

        views = listOf(home, playersScroll, settings)
        views.forEach { main.addView(it, LinearLayout.LayoutParams(-1, 0, 1f)) }
        setContentView(root)
        applyDim(); applyAwake()
        setTab(0)
    }

    private fun section(t: String) = tv(t, 12f, ORANGE, true).apply {
        letterSpacing = 0.15f; setPadding(0, dp(18), 0, dp(2))
    }

    private fun toggle(title: String, key: String, def: Boolean, onChange: (() -> Unit)? = null) = Switch(this).apply {
        text = title; setTextColor(Color.WHITE); textSize = 14f
        if (!prefs.contains(key)) prefs.edit().putBoolean(key, def).apply()
        isChecked = prefs.getBoolean(key, def); setPadding(0, dp(10), 0, dp(2))
        setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply(); exportSettings(); onChange?.invoke() }
    }

    private fun choice(title: String, key: String, opts: List<String>, def: Int, onChange: (() -> Unit)? = null): View {
        if (!prefs.contains(key)) prefs.edit().putInt(key, def).putString(key + "_v", opts[def]).apply()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        box.addView(tv(title, 14f, Color.WHITE))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = ArrayList<TextView>()
        fun paint() {
            val sel = prefs.getInt(key, def)
            chips.forEachIndexed { i, c ->
                c.setTextColor(if (i == sel) Color.WHITE else MUTED)
                c.background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    if (i == sel) setColor(PINK) else { setColor(Color.parseColor("#33FFFFFF")) }
                }
            }
        }
        opts.forEachIndexed { i, o ->
            val c = TextView(this).apply {
                text = o; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setOnClickListener {
                    prefs.edit().putInt(key, i).putString(key + "_v", o).apply()
                    paint(); exportSettings(); onChange?.invoke()
                }
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginEnd = dp(6); topMargin = dp(6) })
        }
        paint()
        box.addView(row)
        return box
    }

    private fun clientDir() = File(Environment.getExternalStorageDirectory(), "Android/data/${Config.CLIENT_PACKAGE}/files")

    /** Writes the game settings (gfx_, aud_, hud_, chat_, game_) to the client folder when Android allows it. */
    private fun exportSettings(): Boolean {
        try {
            val dir = File(clientDir(), "SAMP")
            if (!Installer.canWrite(dir)) return false
            val sb = StringBuilder()
            val groups = linkedMapOf("gfx_" to "graphics", "aud_" to "audio", "hud_" to "hud", "chat_" to "chat", "game_" to "gameplay")
            for ((prefix, section) in groups) {
                sb.append("[$section]\n")
                prefs.all.entries
                    .filter { it.key.startsWith(prefix) && !it.key.endsWith("_v") }
                    .sortedBy { it.key }
                    .forEach { e ->
                        val v = when (val x = e.value) {
                            is Boolean -> if (x) "1" else "0"
                            is Int -> prefs.getString(e.key + "_v", x.toString())
                            else -> x.toString()
                        }
                        sb.append("${e.key.removePrefix(prefix)}=$v\n")
                    }
            }
            File(dir, "geoliferp_settings.ini").writeText(sb.toString())
            return true
        } catch (e: Exception) { return false }
    }

    private fun applyDim() {
        val a = intArrayOf(0x00, 0x33, 0x88)[prefs.getInt("ui_dim", 1)]
        dimView.setBackgroundColor(Color.argb(a, 0, 0, 0))
    }

    private fun applyAwake() {
        if (prefs.getBoolean("ui_awake", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun haptic() {
        if (prefs.getBoolean("ui_haptic", true)) window.decorView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun refreshNow() { ui.removeCallbacks(poll); ui.post(poll) }

    private fun setTab(i: Int) {
        tab = i
        socialRow.visibility = if (i == 0) View.VISIBLE else View.GONE
        heroView.visibility = if (i == 0 && heroId != 0 && prefs.getBoolean("ui_hero", true)) View.VISIBLE else View.GONE
        views.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabTvs.forEachIndexed { k, t -> t.setTextColor(if (k == i) Color.WHITE else MUTED) }
        ui.removeCallbacks(poll); ui.post(poll)
    }

    // ---- real server status: SA-MP UDP query every 5 seconds ----
    private val poll = object : Runnable {
        override fun run() {
            Thread {
                val info = SampQuery.info(Config.SERVER_IP, Config.SERVER_PORT)
                val list = if (info != null && info.players in 1..100 && (tab == 0 || tab == 1)) SampQuery.players(Config.SERVER_IP, Config.SERVER_PORT) else null
                runOnUiThread { render(info, list) }
            }.start()
            ui.postDelayed(this, intArrayOf(3000, 5000, 10000)[prefs.getInt("refresh", 1)].toLong())
        }
    }

    override fun onResume() { super.onResume(); ui.removeCallbacks(poll); ui.post(poll) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    private fun render(i: ServerInfo?, list: List<PlayerInfo>?) {
        if (i == null) {
            pillTv.text = "\u25CF OFFLINE"; pillTv.setTextColor(Color.parseColor("#FF4D4D"))
            infoTv.text = "${Config.SERVER_NAME} Mobile  \u00B7  v1.0"
        } else {
            pillTv.text = "\u25CF ${i.players} / ${i.maxPlayers}"; pillTv.setTextColor(Color.parseColor("#2ECC71"))
            infoTv.text = "${Config.SERVER_NAME} Mobile  \u00B7  v1.0"
        }
        updateStatusCard(i, list)
        if (tab == 1) {
            playersBox.removeAllViews()
            playersBox.addView(tv("ONLINE: ${i?.players ?: 0}", 16f, Color.WHITE, true))
            if (i == null) playersBox.addView(tv("Serveri offline-ia", 13f, Color.LTGRAY))
            else if (list == null) playersBox.addView(tv("Motamasheebis sia xelmisawvdomia mxolod 100-mde motamasheze", 13f, Color.LTGRAY))
            else list.sortedBy { it.id }.forEach {
                playersBox.addView(tv("#${it.id}   ${it.name}   \u2022   score ${it.score}   \u2022   ${it.ping} ms", 13f, Color.WHITE),
                    LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
            }
        }
    }

    private fun updateStatusCard(i: ServerInfo?, list: List<PlayerInfo>?) {
        chipsBox.removeAllViews()
        val grey = Color.parseColor("#A0A0A8")
        if (i == null) {
            statusTv.text = "\u25CF OFFLINE"; statusTv.setTextColor(Color.parseColor("#FF4D4D"))
            countTv.text = "0 / 0"; pingTv.text = "- ms"; fill.progress = 0
            chipsBox.addView(tv("Serveri offline-ia", 12f, grey))
            return
        }
        statusTv.text = "\u25CF ONLINE"; statusTv.setTextColor(Color.parseColor("#2ECC71"))
        countTv.text = "${i.players} / ${i.maxPlayers}"; pingTv.text = "${i.pingMs} ms"
        fill.progress = if (i.maxPlayers > 0) i.players * 100 / i.maxPlayers else 0
        if (!prefs.getBoolean("ui_names", true)) return
        when {
            i.players == 0 -> chipsBox.addView(tv("Motamasheebi jer ar arian online", 12f, grey))
            list == null -> chipsBox.addView(tv("Motamasheebis sia ar aris xelmisawvdomi", 12f, grey))
            else -> list.sortedBy { it.id }.forEach {
                chipsBox.addView(tv(it.name, 12f, Color.WHITE).apply {
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                    background = GradientDrawable().apply { setColor(Color.parseColor("#33FFFFFF")); cornerRadius = dp(12).toFloat() }
                }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
            }
        }
    }

    private fun startInstall() {
        if (Config.FILES_URL.contains("YOUR-HOST")) {
            installMsg.text = "FILES_URL jer ar aris dayenebuli (Config.kt)"; return
        }
        if (Build.VERSION.SDK_INT <= 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            installMsg.text = "Dadastureba ufleba da daachire kvlav"; return
        }
        installBtn.isEnabled = false; installBar.visibility = View.VISIBLE; openZipBtn.visibility = View.GONE
        val target = File(Environment.getExternalStorageDirectory(), "Android/data/${Config.CLIENT_PACKAGE}/files")
        val zip = File(cacheDir, "files.zip")
        Thread {
            try {
                Installer.download(Config.FILES_URL, zip) { p, m -> runOnUiThread { installBar.progress = p; installMsg.text = m } }
                if (Installer.canWrite(target)) {
                    Installer.extract(zip, target) { p, m -> runOnUiThread { installBar.progress = p; installMsg.text = m } }
                    zip.delete()
                    runOnUiThread { installMsg.text = "Mzadaa! Failebi chaiwera Alyn-is foldershi." }
                } else {
                    savedZip = saveToDownloads(zip)
                    zip.delete()
                    runOnUiThread {
                        installBar.progress = 100
                        installMsg.text = "Android-ma pirdapir chaweris ufleba ar mogvca. Zip daimaxsovra: Download/GeoLifeRP_files.zip. " +
                            "Gaxseni ZArchiver-it da Extract aq: Android/data/${Config.CLIENT_PACKAGE}/files"
                        openZipBtn.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { installMsg.text = "Shecdoma: ${e.message}" }
            }
            runOnUiThread { installBtn.isEnabled = true }
        }.start()
    }

    private fun saveToDownloads(zip: File): Uri? {
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "GeoLifeRP_files.zip")
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
            contentResolver.openOutputStream(uri)?.use { o -> zip.inputStream().use { it.copyTo(o) } }
            return uri
        }
        val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "GeoLifeRP_files.zip")
        zip.copyTo(d, overwrite = true)
        return null
    }

    private fun play() {
        haptic()
        val n = nick.text.toString().trim()
        if (!Regex("^[A-Za-z]+_[A-Za-z]+$").matches(n)) {
            Toast.makeText(this, "Nickname unda iyos Name_Surname formatit", Toast.LENGTH_LONG).show(); return
        }
        prefs.edit().putString("nick", n).apply()
        val addr = "${Config.SERVER_IP}:${Config.SERVER_PORT}"
        (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
            .setPrimaryClip(android.content.ClipData.newPlainText("server", addr))
        // 1) try to open the client with the server address (works only if the client supports it)
        val direct = Intent(Intent.ACTION_VIEW, Uri.parse("samp://$addr")).apply {
            setPackage(Config.CLIENT_PACKAGE)
            putExtra("nickname", n); putExtra("ip", Config.SERVER_IP); putExtra("port", Config.SERVER_PORT)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(direct); return } catch (e: Exception) { /* fall through */ }
        // 2) fallback: just open the client
        val li = packageManager.getLaunchIntentForPackage(Config.CLIENT_PACKAGE)
        if (li == null) Toast.makeText(this, "SAMP klienti (${Config.CLIENT_PACKAGE}) ar aris dadgmuli", Toast.LENGTH_LONG).show()
        else {
            Toast.makeText(this, "Serveris misamarti nakopirebulia: $addr", Toast.LENGTH_LONG).show()
            startActivity(li)
        }
    }
}
