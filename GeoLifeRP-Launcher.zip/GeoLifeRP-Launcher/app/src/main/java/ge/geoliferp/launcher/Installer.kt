package ge.geoliferp.launcher

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object Installer {
    /** Downloads [url] into [out]. progress: 0..90 */
    fun download(url: String, out: File, progress: (Int, String) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        val total = c.contentLengthLong
        var done = 0L
        c.inputStream.use { inp ->
            out.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = inp.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val p = if (total > 0) (done * 90 / total).toInt() else 0
                    progress(p, "Yirebs... ${done / 1048576} MB")
                }
            }
        }
    }

    fun canWrite(dir: File): Boolean = try {
        dir.mkdirs()
        val t = File(dir, ".write_test"); t.writeText("x"); t.delete(); true
    } catch (e: Exception) { false }

    /** Extracts the zip into [target], keeping the folder structure. progress: 90..100 */
    fun extract(zip: File, target: File, progress: (Int, String) -> Unit) {
        target.mkdirs()
        val root = target.canonicalPath + File.separator
        var count = 0
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val f = File(target, e.name)
                if (!f.canonicalPath.startsWith(root)) continue // zip-slip datva
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zin.copyTo(it) }
                }
                count++
                progress(90 + minOf(9, count / 20), "Vxsni failebs... $count")
            }
        }
        progress(100, "Mzadaa!")
    }
}
