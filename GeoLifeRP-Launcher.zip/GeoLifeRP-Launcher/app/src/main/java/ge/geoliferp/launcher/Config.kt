package ge.geoliferp.launcher

object Config {
    const val SERVER_NAME = "GeoLifeRP"
    const val SERVER_IP = "188.127.241.74"
    const val SERVER_PORT = 2749
    const val DISCORD = "https://discord.gg/nFan9PxrtE"
    const val WEBSITE = "https://geoliferp.edgeone.dev/"
    const val YOUTUBE = "https://www.youtube.com/@GeoLifeRP"
    const val TIKTOK = "https://www.tiktok.com/@geoliferp?_r=1&_t=ZS-99q1ODgMDjg"
    const val TELEGRAM = "https://t.me/glrpdev"
    const val FACEBOOK = "https://www.facebook.com/share/g/19PTMZQNPz/"
    const val CLIENT_PACKAGE = "ro.alynsampmobile.launcher"
    // TODO: chaanacvle shens zip arqivis pirdapiri linkit (client files + mod-ebi)
    const val FILES_URL = "https://YOUR-HOST/geoliferp_files.zip"
}
