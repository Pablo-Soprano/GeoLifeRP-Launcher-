package ge.geoliferp.launcher

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*

class LoadingActivity : Activity() {
    private val RED = Color.parseColor("#E50914")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!getSharedPreferences("launcher", MODE_PRIVATE).getBoolean("loading", true)) {
            startActivity(Intent(this, MainActivity::class.java)); finish(); return
        }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.loading_bg); scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#66000000")) },
            FrameLayout.LayoutParams(-1, -1))

        root.addView(TextView(this).apply {
            text = "GeoLifeRP Mobile"; textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setShadowLayer(12f, 0f, 2f, RED)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(24), dp(20), 0, 0) })

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), 0, dp(24), dp(20)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val msg = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f }
        val pct = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.END }
        row.addView(msg, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(pct, LinearLayout.LayoutParams(-2, -2))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = android.content.res.ColorStateList.valueOf(RED)
        }
        bottom.addView(row); bottom.addView(bar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(8) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        ValueAnimator.ofInt(0, 100).apply {
            duration = 3500; interpolator = LinearInterpolator()
            addUpdateListener {
                val v = it.animatedValue as Int
                bar.progress = v; pct.text = "$v%"
                msg.text = if (v < 50) "Vtvirtav tamashis failebs..." else if (v < 90) "Vukavshirdebi serverss..." else "Mzadaa!"
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    startActivity(Intent(this@LoadingActivity, MainActivity::class.java)); finish()
                }
            })
            start()
        }
    }
}
